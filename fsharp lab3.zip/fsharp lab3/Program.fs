﻿type Coach = {
    Name: string
    FormerPlayer: bool
}

type Stats = {
    Wins: int
    Losses: int
}

type Team = {
    Name: string
    Coach: Coach
    Stats: Stats
}

let coach1 = { Name = "Steve Kerr"; FormerPlayer = true }
let coach2 = { Name = "Gregg Popovich"; FormerPlayer = true }
let coach3 = { Name = "Doc Rivers"; FormerPlayer = true }
let coach4 = { Name = "Nick Nurse"; FormerPlayer = true }
let coach5 = { Name = "Mike Budenholzer"; FormerPlayer = false }

let stats1 = { Wins = 60; Losses = 22 }
let stats2 = { Wins = 45; Losses = 37 }
let stats3 = { Wins = 52; Losses = 30 }
let stats4 = { Wins = 50; Losses = 32 }
let stats5 = { Wins = 42; Losses = 40 }

let teams = [
    { Name = "Golden State Warriors"; Coach = coach1; Stats = stats1 }
    { Name = "San Antonio Spurs"; Coach = coach2; Stats = stats2 }
    { Name = "Los Angeles Clippers"; Coach = coach3; Stats = stats3 }
    { Name = "Toronto Raptors"; Coach = coach4; Stats = stats4 }
    { Name = "Milwaukee Bucks"; Coach = coach5; Stats = stats5 }
]

let successfulTeams = 
    teams |> List.filter (fun team -> team.Stats.Wins > team.Stats.Losses)

let calculateSuccessPercentage team =
    let totalGames = float (team.Stats.Wins + team.Stats.Losses)
    let successRate = (float team.Stats.Wins) / totalGames * 100.0
    successRate

let successPercentages = 
    teams |> List.map (fun team -> (team.Name, team.Coach.Name, calculateSuccessPercentage team))

printfn "Successful teams (Wins > Losses):"
successfulTeams |> List.iter (fun team -> 
    printfn "%s (Coach: %s): %d Wins, %d Losses" team.Name team.Coach.Name team.Stats.Wins team.Stats.Losses
)

printfn "\nSuccess Percentages with Coach Names:"
successPercentages |> List.iter (fun (name, coachName, percentage) -> 
    printfn "%s (Coach: %s): %.2f%% Success" name coachName percentage
)

//second part
type Cuisine =
    | Korean
    | Turkish

type MovieType =
    | Regular
    | IMAX
    | DBOX
    | RegularWithSnacks
    | IMAXWithSnacks
    | DBOXWithSnacks

type Activity =
    | BoardGame
    | Chill
    | Movie of MovieType
    | Restaurant of Cuisine
    | LongDrive of int * float 

let calculateBudget (activity: Activity) =
    match activity with
    | BoardGame -> 0.0 
    | Chill -> 0.0    
    | Movie(Regular) -> 12.0 * 2.0 
    | Movie(IMAX) -> 17.0 * 2.0    
    | Movie(DBOX) -> 20.0 * 2.0    
    | Movie(RegularWithSnacks) -> 17.0 * 2.0 
    | Movie(IMAXWithSnacks) -> 22.0 * 2.0    
    | Movie(DBOXWithSnacks) -> 25.0 * 2.0   
    | Restaurant(Korean) -> 70.0 
    | Restaurant(Turkish) -> 65.0 
    | LongDrive(km, fuelChargePerKm) -> float km * fuelChargePerKm 

let allActivities = [
    BoardGame                
    Chill                    
    Movie(Regular)          
    Movie(IMAX)              
    Movie(DBOX)              
    Movie(RegularWithSnacks) 
    Movie(IMAXWithSnacks)    
    Movie(DBOXWithSnacks)   
    Restaurant(Korean)       
    Restaurant(Turkish)      
    LongDrive(30, 1.5)       
]

let selectedActivities = [
    BoardGame                
    Chill                    
    Movie(IMAXWithSnacks)    
    Restaurant(Turkish)      
    LongDrive(30, 1.5)       
]

allActivities |> List.iter (fun activity ->
    let budget = calculateBudget activity
    match activity with
    | BoardGame -> printfn "Board Game: %.2f CAD" budget
    | Chill -> printfn "Chill Out: %.2f CAD" budget
    | Movie(Regular) -> printfn "Movie (Regular): %.2f CAD" budget
    | Movie(IMAX) -> printfn "Movie (IMAX): %.2f CAD" budget
    | Movie(DBOX) -> printfn "Movie (DBOX): %.2f CAD" budget
    | Movie(RegularWithSnacks) -> printfn "Movie (RegularWithSnacks): %.2f CAD" budget
    | Movie(IMAXWithSnacks) -> printfn "Movie (IMAXWithSnacks): %.2f CAD" budget
    | Movie(DBOXWithSnacks) -> printfn "Movie (DBOXWithSnacks): %.2f CAD" budget
    | Restaurant(Korean) -> printfn "Restaurant (Korean): %.2f CAD" budget
    | Restaurant(Turkish) -> printfn "Restaurant (Turkish): %.2f CAD" budget
    | LongDrive(km, fuelCharge) -> printfn "Long Drive (%d km, %.2f per km): %.2f CAD" km fuelCharge budget
)

let totalBudget = selectedActivities |> List.sumBy calculateBudget
printfn "\nTotal Budget for selected activities: %.2f CAD" totalBudget
